~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~

- Title                    -> Minimalist Name Input Demo
- Version                  -> v1.1
- Development Tool         -> RPG Maker VX Ace
- Author                   -> Jetpackgone
- Genre                    -> Demo for script

~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~

~ How to Start ~

Extract the .zip file and simply run Game.exe. If a message appears warning you
the file may be unsafe, ignore it. It appears only because of the executable 
file. the game is safe for your computer to play!

No RPG Maker RTPs are required.

~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~

~ Instructions ~

Open up scripts and scroll down to Minimalist Name Input.

~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~

~ Update Log ~
11/21/2014 - v1.1 and README created

~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~
